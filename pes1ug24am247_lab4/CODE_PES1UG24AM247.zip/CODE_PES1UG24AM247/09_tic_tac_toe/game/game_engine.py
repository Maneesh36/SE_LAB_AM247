"""
GameEngine: owns the board, turn state, scoreboard, and round-end logic.

Task 1: Win and draw detection.
Task 2: Persistent scoreboard.
Task 3: Turn and move validation.
Task 4: First-player choice and separate restart controls.
"""

from game.rules import check_winner, is_board_full
from game.renderer import board_pos_to_cell
from game.ai import choose_move

HUMAN_SYMBOL = 'X'
COMPUTER_SYMBOL = 'O'


class GameEngine:
    def __init__(self):
        self.score = {
            'X': 0,
            'O': 0,
            'draws': 0
        }

        self.starting_player = HUMAN_SYMBOL

        self.reset_round()

    def reset_round(self):
        """Start a new round without clearing the scoreboard."""
        self.board = [[None] * 3 for _ in range(3)]
        self.current_player = self.starting_player
        self.round_over = False
        self.winner = None

        if self.current_player == COMPUTER_SYMBOL:
            self._maybe_take_computer_turn()

    def reset_match(self):
        """Reset the entire match, including the scoreboard."""
        self.score = {
            'X': 0,
            'O': 0,
            'draws': 0
        }

        self.reset_round()

    def set_starting_player(self, player):
        """Choose X or O as the first player and start a new round."""
        if player not in (HUMAN_SYMBOL, COMPUTER_SYMBOL):
            return

        self.starting_player = player
        self.reset_round()

    def handle_click(self, pos):
        if self.round_over or self.current_player != HUMAN_SYMBOL:
            return

        cell = board_pos_to_cell(pos)

        if cell is None:
            return

        row, col = cell

        # Task 3: reject clicks on occupied cells.
        if self.board[row][col] is not None:
            return

        self.board[row][col] = self.current_player

        self.check_round_end()

        if self.round_over:
            return

        self.current_player = COMPUTER_SYMBOL
        self._maybe_take_computer_turn()

    def _maybe_take_computer_turn(self):
        if self.round_over or self.current_player != COMPUTER_SYMBOL:
            return

        move = choose_move(self.board)

        if move is None:
            return

        row, col = move

        if self.board[row][col] is not None:
            return

        self.board[row][col] = self.current_player

        self.check_round_end()

        if self.round_over:
            return

        self.current_player = HUMAN_SYMBOL

    def handle_keydown(self, key):
        import pygame

        if key == pygame.K_r:
            self.reset_round()

    def check_round_end(self):
        if self.round_over:
            return

        winner = check_winner(self.board)

        if winner:
            self.round_over = True
            self.winner = winner
            self.score[winner] += 1
            return

        if is_board_full(self.board):
            self.round_over = True
            self.winner = None
            self.score['draws'] += 1

    def draw(self, surface, font):
        from game import renderer

        renderer.draw_board(surface, self.board)

        turn_label = (
            "Your turn (X)"
            if self.current_player == HUMAN_SYMBOL
            else "Computer's turn (O)"
        )

        renderer.draw_text(
            surface,
            font,
            turn_label,
            (10, 15)
        )

        scoreboard_text = (
            f"X Wins: {self.score['X']}   "
            f"O Wins: {self.score['O']}   "
            f"Draws: {self.score['draws']}"
        )

        renderer.draw_text(
            surface,
            font,
            scoreboard_text,
            (10, 45)
        )

        if self.round_over:
            text = f"{self.winner} wins!" if self.winner else "Draw!"

            renderer.draw_banner(
                surface,
                font,
                text
            )   