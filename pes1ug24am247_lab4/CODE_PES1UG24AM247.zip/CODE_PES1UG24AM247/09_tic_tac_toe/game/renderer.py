"""
renderer: all pygame drawing lives here, kept separate from game logic.
"""

import pygame

WIDTH, HEIGHT = 400, 600

BOARD_SIZE = 360
CELL_SIZE = BOARD_SIZE // 3
BOARD_TOP = 100

WINDOW_SIZE = (WIDTH, HEIGHT)

COLOR_BG = (245, 245, 245)
COLOR_LINE = (60, 60, 60)
COLOR_X = (200, 60, 60)
COLOR_O = (60, 100, 200)
COLOR_TEXT = (30, 30, 30)
COLOR_BUTTON = (220, 220, 220)
COLOR_BUTTON_HOVER = (200, 200, 200)


def board_pos_to_cell(pos):
    x, y = pos

    y -= BOARD_TOP

    if not (0 <= x < BOARD_SIZE and 0 <= y < BOARD_SIZE):
        return None

    col = x // CELL_SIZE
    row = y // CELL_SIZE

    return int(row), int(col)


def draw_board(surface, board):
    surface.fill(COLOR_BG)

    for i in range(1, 3):
        pygame.draw.line(
            surface,
            COLOR_LINE,
            (i * CELL_SIZE, BOARD_TOP),
            (i * CELL_SIZE, BOARD_TOP + BOARD_SIZE),
            3
        )

        pygame.draw.line(
            surface,
            COLOR_LINE,
            (0, BOARD_TOP + i * CELL_SIZE),
            (BOARD_SIZE, BOARD_TOP + i * CELL_SIZE),
            3
        )

    for r in range(3):
        for c in range(3):
            symbol = board[r][c]

            if symbol is None:
                continue

            center = (
                c * CELL_SIZE + CELL_SIZE // 2,
                BOARD_TOP + r * CELL_SIZE + CELL_SIZE // 2
            )

            if symbol == 'X':
                offset = CELL_SIZE // 3

                pygame.draw.line(
                    surface,
                    COLOR_X,
                    (center[0] - offset, center[1] - offset),
                    (center[0] + offset, center[1] + offset),
                    6
                )

                pygame.draw.line(
                    surface,
                    COLOR_X,
                    (center[0] + offset, center[1] - offset),
                    (center[0] - offset, center[1] + offset),
                    6
                )

            else:
                pygame.draw.circle(
                    surface,
                    COLOR_O,
                    center,
                    CELL_SIZE // 3,
                    6
                )


def draw_text(surface, font, text, pos, color=COLOR_TEXT):
    surface.blit(
        font.render(text, True, color),
        pos
    )


def draw_banner(surface, font, text):
    surf = font.render(
        text,
        True,
        (180, 40, 40)
    )

    rect = surf.get_rect(
        center=(
            surface.get_width() // 2,
            BOARD_TOP + BOARD_SIZE + 25
        )
    )

    surface.blit(surf, rect)


def get_x_start_button():
    return pygame.Rect(10, 530, 85, 40)


def get_o_start_button():
    return pygame.Rect(105, 530, 85, 40)


def get_new_round_button():
    return pygame.Rect(205, 530, 85, 40)


def get_reset_match_button():
    return pygame.Rect(300, 530, 90, 40)


def draw_button(surface, font, rect, text, mouse_pos):
    color = (
        COLOR_BUTTON_HOVER
        if rect.collidepoint(mouse_pos)
        else COLOR_BUTTON
    )

    pygame.draw.rect(
        surface,
        color,
        rect,
        border_radius=6
    )

    pygame.draw.rect(
        surface,
        COLOR_LINE,
        rect,
        2,
        border_radius=6
    )

    # Smaller font so all button labels fit.
    button_font = pygame.font.SysFont("consolas", 14)

    text_surface = button_font.render(
        text,
        True,
        COLOR_TEXT
    )

    text_rect = text_surface.get_rect(
        center=rect.center
    )

    surface.blit(
        text_surface,
        text_rect
    )


def draw_controls(surface, font, mouse_pos):
    draw_button(
        surface,
        font,
        get_x_start_button(),
        "X Starts",
        mouse_pos
    )

    draw_button(
        surface,
        font,
        get_o_start_button(),
        "O Starts",
        mouse_pos
    )

    draw_button(
        surface,
        font,
        get_new_round_button(),
        "New Round",
        mouse_pos
    )

    draw_button(
        surface,
        font,
        get_reset_match_button(),
        "Reset",
        mouse_pos
    )