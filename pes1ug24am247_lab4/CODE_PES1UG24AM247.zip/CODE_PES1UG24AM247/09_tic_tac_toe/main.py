"""
Tic-Tac-Toe (Lab)

Run with: python main.py
"""

import pygame

from game.game_engine import GameEngine
from game.renderer import (
    WINDOW_SIZE,
    get_x_start_button,
    get_o_start_button,
    get_new_round_button,
    get_reset_match_button,
    draw_controls
)


def main():
    pygame.init()

    screen = pygame.display.set_mode(WINDOW_SIZE)
    pygame.display.set_caption("Tic-Tac-Toe")

    clock = pygame.time.Clock()

    font = pygame.font.SysFont(
        "consolas",
        22
    )

    engine = GameEngine()

    running = True

    while running:
        mouse_pos = pygame.mouse.get_pos()

        for event in pygame.event.get():

            if event.type == pygame.QUIT:
                running = False

            elif event.type == pygame.MOUSEBUTTONDOWN:

                if get_x_start_button().collidepoint(event.pos):
                    engine.set_starting_player('X')

                elif get_o_start_button().collidepoint(event.pos):
                    engine.set_starting_player('O')

                elif get_new_round_button().collidepoint(event.pos):
                    engine.reset_round()

                elif get_reset_match_button().collidepoint(event.pos):
                    engine.reset_match()

                else:
                    engine.handle_click(event.pos)

            elif event.type == pygame.KEYDOWN:
                engine.handle_keydown(event.key)

        engine.draw(screen, font)

        draw_controls(
            screen,
            font,
            mouse_pos
        )

        pygame.display.flip()

        clock.tick(60)

    pygame.quit()


if __name__ == "__main__":
    main()